﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using BL.Amlo.Autorizing;
using DTO.Amlo.Autorizing;
using BAL.Amlo.Autorizing;

namespace ANZ2AMLO.Forms
{
    public partial class frmMenuPermission : DevExpress.XtraEditors.XtraForm
    {
        UserGroupBL blUserGroup = new UserGroupBL();
        MenuGroupBL blMenuGroup = new MenuGroupBL();
        string pKeyName = "MENU_OID";
        List<PER_MENU_PERMISSIONDto> dtMenuPermissionList = null;
        string userGroupOID = "";
        PER_MENU_PERMISSIONBL blPermmission = new PER_MENU_PERMISSIONBL();
        string currentUserGroup = "";

        private void initialData()
        {
            DataTable dtUserGroup = blUserGroup.FindByAll();
            cbUserGroupSearch.DataSource = dtUserGroup;
            cbUserGroupSearch.DisplayMember = "Name";
            cbUserGroupSearch.ValueMember = "USERGROUP_OID";
            DataRow dr = dtUserGroup.NewRow();
            dr["Name"] = "-- Please Select --";
            dr["USERGROUP_OID"] = "";
            dtUserGroup.Rows.InsertAt(dr, 0);
            cbUserGroupSearch.SelectedIndex = 0;
        }

        void SearchData()
        {
            treeMenu.Nodes[0].Nodes.Clear();
            treeMenu.Nodes[0].Text = "Menu";

            if (cbUserGroupSearch.SelectedIndex == 0)
            {
                MessageBox.Show("Please select Group", ".:Menu Permission");
            }
            else
            {
                currentUserGroup = cbUserGroupSearch.SelectedValue.ToString();
                treeMenu.Nodes[0].Text = "Menu for group : " + cbUserGroupSearch.Text;
                DataTable dt = blMenuGroup.FindMenuPermissionByUserGroup(currentUserGroup);
                CreateTreeMenu(dt);
                btnSave.Enabled = true;
            }
        }

        void CreateTreeMenu(DataTable dtMenu)
        {
            DataView dv = new DataView(dtMenu);
            dv.RowFilter = string.Format("[MENUGROUP_OID]=''");
            string[] menu = { "Menu1", "Menu2" };

            foreach (DataRowView node in dv)
            {
                TreeNode mainmenu = new TreeNode();
                mainmenu.Text = node["Name"].ToString();
                mainmenu.Name = node[pKeyName].ToString();
                mainmenu.Checked = node["VIEW"].ToString().Equals("1") ? true : false;
                CreateSubTreeMenu(mainmenu, dtMenu, node);
                treeMenu.Nodes[0].Nodes.Add(mainmenu);
            }
        }

        void CreateSubTreeMenu(TreeNode hNode, DataTable dtAllMenu, DataRowView dtGroupMenu)
        {
            DataView dv = new DataView(dtAllMenu);
            dv.RowFilter = string.Format("[MENUGROUP_OID]='{0}'", dtGroupMenu["MENU_OID"]);

            foreach (DataRowView node in dv)
            {
                TreeNode mainmenu = new TreeNode();
                mainmenu.Text = node["Name"].ToString();
                mainmenu.Name = node[pKeyName].ToString();
                mainmenu.Checked = node["VIEW"].ToString().Equals("1") ? true : false;
                hNode.Nodes.Add(mainmenu);
            }
        }

        private void saveMenuPermission()
        {
            CollectResult();
            blPermmission.Save(currentUserGroup, dtMenuPermissionList);
            MessageBox.Show("Save Menu Permission successfully.", ".:Menu Permission");
        }

        List<PER_MENU_PERMISSIONDto> CollectResult()
        {
            dtMenuPermissionList = new List<PER_MENU_PERMISSIONDto>();

            List<PER_MENU_PERMISSIONDto> subMenuList = new List<PER_MENU_PERMISSIONDto>();

            PER_MENU_PERMISSIONDto clientMenu = null;

            userGroupOID = cbUserGroupSearch.SelectedIndex > 0 ? cbUserGroupSearch.SelectedValue.ToString() : "";
            DataTable dtSelectMenu = PER_MENU_PERMISSIONDto.Data();

            if (userGroupOID != "")
            {
                foreach (TreeNode menu in treeMenu.Nodes[0].Nodes)
                {
                    clientMenu = new PER_MENU_PERMISSIONDto();

                    clientMenu.USERGROUP_OID = userGroupOID;
                    clientMenu.MENU_OID = menu.Name;
                    clientMenu.ROW_STATE = "1";
                    clientMenu.CREATE_BY = "Admin";
                    if (menu.Checked)
                    {
                        clientMenu.VIEW = "1";
                        clientMenu.DELETE = "1";
                        clientMenu.EDIT = "1";

                        dtMenuPermissionList.Add(clientMenu);
                    }
                    subMenuList = CollectSubmenuResult(menu);
                    dtMenuPermissionList.AddRange(subMenuList);
                }
            }
            return dtMenuPermissionList;
        }

        List<PER_MENU_PERMISSIONDto> CollectSubmenuResult(TreeNode hNode)
        {
            List<PER_MENU_PERMISSIONDto> menuList = new List<PER_MENU_PERMISSIONDto>();
            PER_MENU_PERMISSIONDto clientMenu = null;

            if (hNode.Nodes.Count > 0)
            {
                foreach (TreeNode menu in hNode.Nodes)
                {
                    clientMenu = new PER_MENU_PERMISSIONDto(); ;
                    clientMenu.USERGROUP_OID = userGroupOID;
                    clientMenu.MENU_OID = menu.Name;
                    clientMenu.ROW_STATE = "1";
                    clientMenu.CREATE_BY = "Admin";
                    if (menu.Checked)
                    {
                        clientMenu.VIEW = "1";
                        clientMenu.DELETE = "1";
                        clientMenu.EDIT = "1";

                        menuList.Add(clientMenu);
                    }
                }
            }
            return menuList;
        }

        public frmMenuPermission()
        {
            InitializeComponent();
        }

        private void frmMenuPermission_Load(object sender, EventArgs e)
        {
            initialData();
            btnSave.Enabled = false;
        }

        private void btnSave_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            saveMenuPermission();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            SearchData();
        }
    }
}