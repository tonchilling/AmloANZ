﻿namespace ANZ1AMLO.Forms
{
    partial class frmCustomerMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode2 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions1 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject4 = new DevExpress.Utils.SerializableAppearanceObject();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCustomerMaster));
            DevExpress.XtraGrid.GridLevelNode gridLevelNode3 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions2 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject5 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject6 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject7 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject8 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions3 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject9 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject10 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject11 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject12 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions4 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject13 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject14 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject15 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject16 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode4 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions5 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject17 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject18 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject19 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject20 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions6 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject21 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject22 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject23 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject24 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions7 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject25 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject26 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject27 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject28 = new DevExpress.Utils.SerializableAppearanceObject();
            this.gridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gdAccCustomerID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gdAccAccountNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gdView = new DevExpress.XtraGrid.GridControl();
            this.gridView4 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.No = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnViewCustomer = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnView = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.CustomerNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.CustomerID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.CustomerACNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.RegBusinessName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.RegBusinessNameTH = new DevExpress.XtraGrid.Columns.GridColumn();
            this.CustomerName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.JuristicIDNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colHID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.RegisterDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.PrimaryBusinessTypeCode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.ContactTelNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.DefaultAddress = new DevExpress.XtraGrid.Columns.GridColumn();
            this.RegisterAddress = new DevExpress.XtraGrid.Columns.GridColumn();
            this.ContactAddress = new DevExpress.XtraGrid.Columns.GridColumn();
            this.CompanyAdd = new DevExpress.XtraGrid.Columns.GridColumn();
            this.SourceFile_MappingDetailName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.CustomerOID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.bar2 = new DevExpress.XtraBars.Bar();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.popupContainerControl1 = new DevExpress.XtraEditors.PopupContainerControl();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.gdAddress = new DevExpress.XtraGrid.GridControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.RelateCustomerKYCID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.PrincipleAddress = new DevExpress.XtraGrid.Columns.GridColumn();
            this.City = new DevExpress.XtraGrid.Columns.GridColumn();
            this.State = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Zipcode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Country = new DevExpress.XtraGrid.Columns.GridColumn();
            this.ContactNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.AddressOID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Address_CREATE_BY = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Address_CREATE_DATE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Address_UPDATE_BY = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Address_UPDATE_DATE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Address_CustomerOID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.repositoryItemButtonEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.repositoryItemButtonEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gdAccount = new DevExpress.XtraGrid.GridControl();
            this.gridViewResult = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.AccountNumber = new DevExpress.XtraGrid.Columns.GridColumn();
            this.CurrencyCode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.AccountType = new DevExpress.XtraGrid.Columns.GridColumn();
            this.SourceBankBranch = new DevExpress.XtraGrid.Columns.GridColumn();
            this.AccountCustomerOID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.CREATE_BY = new DevExpress.XtraGrid.Columns.GridColumn();
            this.CREATE_DATE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.UPDATE_BY = new DevExpress.XtraGrid.Columns.GridColumn();
            this.UPDATE_DATE = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.btnEdit = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.btnDelete = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtPrimaryBusinessType = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtRegBusinessName = new System.Windows.Forms.TextBox();
            this.txtCustomerNO = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCustomerID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txtRegisterDate = new System.Windows.Forms.TextBox();
            this.txtRegBusinessNameTH = new System.Windows.Forms.TextBox();
            this.txtJuristicIDNo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnClose = new DevExpress.XtraEditors.ButtonEdit();
            this.splashScreenManager1 = new DevExpress.XtraSplashScreen.SplashScreenManager(this, typeof(global::ANZ2AMLO.Forms.WaitForm1), true, true);
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.popupContainerControl1)).BeginInit();
            this.popupContainerControl1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gdAddress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit3)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gdAccount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewResult)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // gridView3
            // 
            this.gridView3.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gdAccCustomerID,
            this.gdAccAccountNumber});
            this.gridView3.GridControl = this.gdView;
            this.gridView3.Name = "gridView3";
            // 
            // gdAccCustomerID
            // 
            this.gdAccCustomerID.Caption = "gridColumn1";
            this.gdAccCustomerID.FieldName = "CustomerOID";
            this.gdAccCustomerID.Name = "gdAccCustomerID";
            this.gdAccCustomerID.Visible = true;
            this.gdAccCustomerID.VisibleIndex = 0;
            // 
            // gdAccAccountNumber
            // 
            this.gdAccAccountNumber.Caption = "gridColumn1";
            this.gdAccAccountNumber.FieldName = "AccountNumber";
            this.gdAccAccountNumber.Name = "gdAccAccountNumber";
            this.gdAccAccountNumber.Visible = true;
            this.gdAccAccountNumber.VisibleIndex = 1;
            // 
            // gdView
            // 
            this.gdView.Dock = System.Windows.Forms.DockStyle.Fill;
            gridLevelNode1.LevelTemplate = this.gridView3;
            gridLevelNode1.RelationName = "Account";
            gridLevelNode2.LevelTemplate = this.gridView4;
            gridLevelNode2.RelationName = "Address";
            this.gdView.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1,
            gridLevelNode2});
            this.gdView.Location = new System.Drawing.Point(0, 88);
            this.gdView.MainView = this.gridView1;
            this.gdView.Name = "gdView";
            this.gdView.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.btnView});
            this.gdView.Size = new System.Drawing.Size(1097, 616);
            this.gdView.TabIndex = 15;
            this.gdView.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView4,
            this.gridView1,
            this.gridView3});
            // 
            // gridView4
            // 
            this.gridView4.GridControl = this.gdView;
            this.gridView4.Name = "gridView4";
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.No,
            this.btnViewCustomer,
            this.CustomerNo,
            this.CustomerID,
            this.CustomerACNo,
            this.RegBusinessName,
            this.RegBusinessNameTH,
            this.CustomerName,
            this.JuristicIDNo,
            this.colDID,
            this.colHID,
            this.RegisterDate,
            this.PrimaryBusinessTypeCode,
            this.ContactTelNumber,
            this.DefaultAddress,
            this.RegisterAddress,
            this.ContactAddress,
            this.CompanyAdd,
            this.SourceFile_MappingDetailName,
            this.CustomerOID});
            this.gridView1.GridControl = this.gdView;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.AllowIncrementalSearch = true;
            this.gridView1.OptionsDetail.EnableMasterViewMode = false;
            this.gridView1.OptionsFind.AlwaysVisible = true;
            this.gridView1.OptionsView.AllowHtmlDrawHeaders = true;
            this.gridView1.OptionsView.BestFitMode = DevExpress.XtraGrid.Views.Grid.GridBestFitMode.Fast;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.SynchronizeClones = false;
            this.gridView1.MasterRowExpanded += new DevExpress.XtraGrid.Views.Grid.CustomMasterRowEventHandler(this.gridView1_MasterRowExpanded);
            // 
            // No
            // 
            this.No.Caption = "No";
            this.No.FieldName = "No";
            this.No.MaxWidth = 50;
            this.No.Name = "No";
            this.No.Visible = true;
            this.No.VisibleIndex = 1;
            this.No.Width = 50;
            // 
            // btnViewCustomer
            // 
            this.btnViewCustomer.Caption = "View";
            this.btnViewCustomer.ColumnEdit = this.btnView;
            this.btnViewCustomer.MaxWidth = 80;
            this.btnViewCustomer.Name = "btnViewCustomer";
            this.btnViewCustomer.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            this.btnViewCustomer.Visible = true;
            this.btnViewCustomer.VisibleIndex = 0;
            // 
            // btnView
            // 
            this.btnView.AutoHeight = false;
            this.btnView.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Flat;
            this.btnView.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "VIEW", -1, true, true, false, editorButtonImageOptions1, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, serializableAppearanceObject2, serializableAppearanceObject3, serializableAppearanceObject4, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.btnView.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.btnView.Name = "btnView";
            this.btnView.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // CustomerNo
            // 
            this.CustomerNo.Caption = "Cutomer No";
            this.CustomerNo.FieldName = "CustomerNo";
            this.CustomerNo.Name = "CustomerNo";
            this.CustomerNo.Visible = true;
            this.CustomerNo.VisibleIndex = 2;
            this.CustomerNo.Width = 50;
            // 
            // CustomerID
            // 
            this.CustomerID.Caption = "Customer ID";
            this.CustomerID.FieldName = "CustomerID";
            this.CustomerID.MaxWidth = 100;
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.Visible = true;
            this.CustomerID.VisibleIndex = 3;
            // 
            // CustomerACNo
            // 
            this.CustomerACNo.Caption = "Customer A/C No. (M)";
            this.CustomerACNo.FieldName = "CustomerACNo";
            this.CustomerACNo.MaxWidth = 50;
            this.CustomerACNo.Name = "CustomerACNo";
            this.CustomerACNo.Width = 50;
            // 
            // RegBusinessName
            // 
            this.RegBusinessName.Caption = "Registered Business Name";
            this.RegBusinessName.FieldName = "RegBusinessName";
            this.RegBusinessName.MaxWidth = 80;
            this.RegBusinessName.Name = "RegBusinessName";
            this.RegBusinessName.Visible = true;
            this.RegBusinessName.VisibleIndex = 5;
            // 
            // RegBusinessNameTH
            // 
            this.RegBusinessNameTH.Caption = "Registered Business Name TH";
            this.RegBusinessNameTH.FieldName = "RegBusinessNameTH";
            this.RegBusinessNameTH.MaxWidth = 80;
            this.RegBusinessNameTH.Name = "RegBusinessNameTH";
            this.RegBusinessNameTH.Visible = true;
            this.RegBusinessNameTH.VisibleIndex = 6;
            // 
            // CustomerName
            // 
            this.CustomerName.Caption = "Customer Name (MIDANZ)";
            this.CustomerName.FieldName = "CustomerName";
            this.CustomerName.MaxWidth = 80;
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.UnboundType = DevExpress.Data.UnboundColumnType.String;
            this.CustomerName.Visible = true;
            this.CustomerName.VisibleIndex = 7;
            // 
            // JuristicIDNo
            // 
            this.JuristicIDNo.Caption = "Juristic ID Number";
            this.JuristicIDNo.FieldName = "JuristicIDNo";
            this.JuristicIDNo.MaxWidth = 80;
            this.JuristicIDNo.Name = "JuristicIDNo";
            this.JuristicIDNo.Visible = true;
            this.JuristicIDNo.VisibleIndex = 4;
            // 
            // colDID
            // 
            this.colDID.Caption = "DID";
            this.colDID.FieldName = "colDID";
            this.colDID.MinWidth = 10;
            this.colDID.Name = "colDID";
            // 
            // colHID
            // 
            this.colHID.Caption = "HID";
            this.colHID.FieldName = "colHID";
            this.colHID.Name = "colHID";
            // 
            // RegisterDate
            // 
            this.RegisterDate.Caption = "Register Date ( EN:DD/MM/YYYY)";
            this.RegisterDate.FieldName = "RegisterDate";
            this.RegisterDate.Name = "RegisterDate";
            this.RegisterDate.Visible = true;
            this.RegisterDate.VisibleIndex = 8;
            // 
            // PrimaryBusinessTypeCode
            // 
            this.PrimaryBusinessTypeCode.Caption = "Primary Business Type Code";
            this.PrimaryBusinessTypeCode.FieldName = "PrimaryBusinessTypeCode";
            this.PrimaryBusinessTypeCode.Name = "PrimaryBusinessTypeCode";
            this.PrimaryBusinessTypeCode.Visible = true;
            this.PrimaryBusinessTypeCode.VisibleIndex = 9;
            // 
            // ContactTelNumber
            // 
            this.ContactTelNumber.Caption = "Contact Tel Number";
            this.ContactTelNumber.FieldName = "ContactTelNumber";
            this.ContactTelNumber.Name = "ContactTelNumber";
            // 
            // DefaultAddress
            // 
            this.DefaultAddress.Caption = "Default Address";
            this.DefaultAddress.FieldName = "DefaultAddress";
            this.DefaultAddress.Name = "DefaultAddress";
            // 
            // RegisterAddress
            // 
            this.RegisterAddress.Caption = "Register Address";
            this.RegisterAddress.FieldName = "RegisterAddress";
            this.RegisterAddress.Name = "RegisterAddress";
            // 
            // ContactAddress
            // 
            this.ContactAddress.Caption = "Contract Address";
            this.ContactAddress.FieldName = "ContactAddress";
            this.ContactAddress.Name = "ContactAddress";
            // 
            // CompanyAdd
            // 
            this.CompanyAdd.Caption = "Company Address";
            this.CompanyAdd.FieldName = "colCompanyAdd";
            this.CompanyAdd.Name = "CompanyAdd";
            // 
            // SourceFile_MappingDetailName
            // 
            this.SourceFile_MappingDetailName.Caption = "gridColumn1";
            this.SourceFile_MappingDetailName.FieldName = "SourceFile_MappingDetailName";
            this.SourceFile_MappingDetailName.Name = "SourceFile_MappingDetailName";
            // 
            // CustomerOID
            // 
            this.CustomerOID.Caption = "gridColumn1";
            this.CustomerOID.FieldName = "CustomerOID";
            this.CustomerOID.GroupInterval = DevExpress.XtraGrid.ColumnGroupInterval.Value;
            this.CustomerOID.Name = "CustomerOID";
            // 
            // barManager1
            // 
            this.barManager1.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar2});
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barButtonItem1,
            this.barButtonItem2,
            this.barButtonItem3,
            this.barButtonItem4});
            this.barManager1.MainMenu = this.bar2;
            this.barManager1.MaxItemId = 4;
            // 
            // bar2
            // 
            this.bar2.BarName = "Main menu";
            this.bar2.DockCol = 0;
            this.bar2.DockRow = 0;
            this.bar2.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem4),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem2)});
            this.bar2.OptionsBar.MultiLine = true;
            this.bar2.OptionsBar.UseWholeRow = true;
            this.bar2.Text = "Main menu";
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "Generate";
            this.barButtonItem4.Id = 3;
            this.barButtonItem4.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem4.ImageOptions.Image")));
            this.barButtonItem4.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("barButtonItem4.ImageOptions.LargeImage")));
            this.barButtonItem4.Name = "barButtonItem4";
            this.barButtonItem4.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem4_ItemClick);
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "Close";
            this.barButtonItem2.Id = 1;
            this.barButtonItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem2.ImageOptions.Image")));
            this.barButtonItem2.Name = "barButtonItem2";
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Manager = this.barManager1;
            this.barDockControlTop.Size = new System.Drawing.Size(1097, 40);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 704);
            this.barDockControlBottom.Manager = this.barManager1;
            this.barDockControlBottom.Size = new System.Drawing.Size(1097, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 40);
            this.barDockControlLeft.Manager = this.barManager1;
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 664);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1097, 40);
            this.barDockControlRight.Manager = this.barManager1;
            this.barDockControlRight.Size = new System.Drawing.Size(0, 664);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Save";
            this.barButtonItem1.Id = 0;
            this.barButtonItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem1.ImageOptions.Image")));
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "Process";
            this.barButtonItem3.Id = 2;
            this.barButtonItem3.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem3.ImageOptions.Image")));
            this.barButtonItem3.Name = "barButtonItem3";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(12, 6);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(98, 13);
            this.labelControl2.TabIndex = 2;
            this.labelControl2.Text = "CUSTOMER MASTER";
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.linkLabel1);
            this.panelControl1.Controls.Add(this.labelControl1);
            this.panelControl1.Controls.Add(this.labelControl2);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelControl1.Location = new System.Drawing.Point(0, 40);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1097, 48);
            this.panelControl1.TabIndex = 16;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(127, 6);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(125, 13);
            this.linkLabel1.TabIndex = 5;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Output (D:\\ANZ\\Output)";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(12, 25);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(295, 13);
            this.labelControl1.TabIndex = 4;
            this.labelControl1.Text = "Lasted Generate Cutomer Date : 15/10/2018 Time : 14:00:31";
            // 
            // popupContainerControl1
            // 
            this.popupContainerControl1.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.popupContainerControl1.Appearance.Options.UseBackColor = true;
            this.popupContainerControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.popupContainerControl1.Controls.Add(this.groupBox3);
            this.popupContainerControl1.Controls.Add(this.groupBox2);
            this.popupContainerControl1.Controls.Add(this.groupBox1);
            this.popupContainerControl1.Controls.Add(this.btnClose);
            this.popupContainerControl1.Location = new System.Drawing.Point(62, 121);
            this.popupContainerControl1.Name = "popupContainerControl1";
            this.popupContainerControl1.Size = new System.Drawing.Size(958, 434);
            this.popupContainerControl1.TabIndex = 21;
            this.popupContainerControl1.Paint += new System.Windows.Forms.PaintEventHandler(this.popupContainerControl1_Paint);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.gdAddress);
            this.groupBox3.Location = new System.Drawing.Point(13, 294);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(929, 131);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Address";
            // 
            // gdAddress
            // 
            this.gdAddress.Dock = System.Windows.Forms.DockStyle.Fill;
            gridLevelNode3.RelationName = "Level1";
            this.gdAddress.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode3});
            this.gdAddress.Location = new System.Drawing.Point(2, 16);
            this.gdAddress.MainView = this.gridView2;
            this.gdAddress.Name = "gdAddress";
            this.gdAddress.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEdit4,
            this.repositoryItemButtonEdit2,
            this.repositoryItemButtonEdit3});
            this.gdAddress.Size = new System.Drawing.Size(925, 113);
            this.gdAddress.TabIndex = 27;
            this.gdAddress.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView2});
            // 
            // gridView2
            // 
            this.gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.RelateCustomerKYCID,
            this.PrincipleAddress,
            this.City,
            this.State,
            this.Zipcode,
            this.Country,
            this.ContactNumber,
            this.AddressOID,
            this.Address_CREATE_BY,
            this.Address_CREATE_DATE,
            this.Address_UPDATE_BY,
            this.Address_UPDATE_DATE,
            this.Address_CustomerOID});
            this.gridView2.GridControl = this.gdAddress;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsBehavior.AllowIncrementalSearch = true;
            this.gridView2.OptionsView.BestFitMode = DevExpress.XtraGrid.Views.Grid.GridBestFitMode.Fast;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            // 
            // RelateCustomerKYCID
            // 
            this.RelateCustomerKYCID.AppearanceHeader.Options.UseTextOptions = true;
            this.RelateCustomerKYCID.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.RelateCustomerKYCID.Caption = "Relate Customer KYC ID";
            this.RelateCustomerKYCID.FieldName = "RelateCustomerKYCID";
            this.RelateCustomerKYCID.Name = "RelateCustomerKYCID";
            this.RelateCustomerKYCID.OptionsColumn.AllowEdit = false;
            this.RelateCustomerKYCID.Visible = true;
            this.RelateCustomerKYCID.VisibleIndex = 0;
            this.RelateCustomerKYCID.Width = 181;
            // 
            // PrincipleAddress
            // 
            this.PrincipleAddress.AppearanceHeader.Options.UseTextOptions = true;
            this.PrincipleAddress.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.PrincipleAddress.Caption = "Principle Address";
            this.PrincipleAddress.FieldName = "PrincipleAddress";
            this.PrincipleAddress.Name = "PrincipleAddress";
            this.PrincipleAddress.OptionsColumn.AllowEdit = false;
            this.PrincipleAddress.Visible = true;
            this.PrincipleAddress.VisibleIndex = 1;
            this.PrincipleAddress.Width = 181;
            // 
            // City
            // 
            this.City.AppearanceHeader.Options.UseTextOptions = true;
            this.City.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.City.Caption = "City";
            this.City.FieldName = "City";
            this.City.Name = "City";
            this.City.OptionsColumn.AllowEdit = false;
            this.City.Visible = true;
            this.City.VisibleIndex = 2;
            this.City.Width = 181;
            // 
            // State
            // 
            this.State.AppearanceHeader.Options.UseTextOptions = true;
            this.State.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.State.Caption = "State";
            this.State.FieldName = "State";
            this.State.MaxWidth = 100;
            this.State.Name = "State";
            this.State.OptionsColumn.AllowEdit = false;
            this.State.Visible = true;
            this.State.VisibleIndex = 3;
            this.State.Width = 87;
            // 
            // Zipcode
            // 
            this.Zipcode.AppearanceHeader.Options.UseTextOptions = true;
            this.Zipcode.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.Zipcode.Caption = "Zipcode";
            this.Zipcode.FieldName = "Zipcode";
            this.Zipcode.MaxWidth = 80;
            this.Zipcode.Name = "Zipcode";
            this.Zipcode.Visible = true;
            this.Zipcode.VisibleIndex = 4;
            this.Zipcode.Width = 67;
            // 
            // Country
            // 
            this.Country.AppearanceHeader.Options.UseTextOptions = true;
            this.Country.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.Country.Caption = "Country";
            this.Country.FieldName = "Country";
            this.Country.Name = "Country";
            this.Country.Visible = true;
            this.Country.VisibleIndex = 5;
            this.Country.Width = 77;
            // 
            // ContactNumber
            // 
            this.ContactNumber.Caption = "Contact Number";
            this.ContactNumber.FieldName = "ContactNumber";
            this.ContactNumber.Name = "ContactNumber";
            this.ContactNumber.Visible = true;
            this.ContactNumber.VisibleIndex = 6;
            // 
            // AddressOID
            // 
            this.AddressOID.Caption = "AddressOID";
            this.AddressOID.FieldName = "AddressOID";
            this.AddressOID.MinWidth = 10;
            this.AddressOID.Name = "AddressOID";
            // 
            // Address_CREATE_BY
            // 
            this.Address_CREATE_BY.Caption = "CREATE_BY";
            this.Address_CREATE_BY.FieldName = "CREATE_BY";
            this.Address_CREATE_BY.Name = "Address_CREATE_BY";
            // 
            // Address_CREATE_DATE
            // 
            this.Address_CREATE_DATE.Caption = "CREATE_DATE";
            this.Address_CREATE_DATE.FieldName = "CREATE_DATE";
            this.Address_CREATE_DATE.Name = "Address_CREATE_DATE";
            // 
            // Address_UPDATE_BY
            // 
            this.Address_UPDATE_BY.Caption = "UPDATE_BY";
            this.Address_UPDATE_BY.FieldName = "UPDATE_BY";
            this.Address_UPDATE_BY.Name = "Address_UPDATE_BY";
            // 
            // Address_UPDATE_DATE
            // 
            this.Address_UPDATE_DATE.Caption = "UPDATE_DATE";
            this.Address_UPDATE_DATE.FieldName = "UPDATE_DATE";
            this.Address_UPDATE_DATE.Name = "Address_UPDATE_DATE";
            // 
            // Address_CustomerOID
            // 
            this.Address_CustomerOID.Caption = "CustomerOID";
            this.Address_CustomerOID.FieldName = "CustomerOID";
            this.Address_CustomerOID.Name = "Address_CustomerOID";
            // 
            // repositoryItemButtonEdit4
            // 
            this.repositoryItemButtonEdit4.AutoHeight = false;
            this.repositoryItemButtonEdit4.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Flat;
            this.repositoryItemButtonEdit4.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "VIEW", -1, true, true, false, editorButtonImageOptions2, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject5, serializableAppearanceObject6, serializableAppearanceObject7, serializableAppearanceObject8, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.repositoryItemButtonEdit4.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.repositoryItemButtonEdit4.Name = "repositoryItemButtonEdit4";
            this.repositoryItemButtonEdit4.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // repositoryItemButtonEdit2
            // 
            this.repositoryItemButtonEdit2.AutoHeight = false;
            this.repositoryItemButtonEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "Edit", -1, true, true, false, editorButtonImageOptions3, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject9, serializableAppearanceObject10, serializableAppearanceObject11, serializableAppearanceObject12, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.repositoryItemButtonEdit2.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.repositoryItemButtonEdit2.Name = "repositoryItemButtonEdit2";
            this.repositoryItemButtonEdit2.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // repositoryItemButtonEdit3
            // 
            this.repositoryItemButtonEdit3.AutoHeight = false;
            this.repositoryItemButtonEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "Delete", -1, true, true, false, editorButtonImageOptions4, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject13, serializableAppearanceObject14, serializableAppearanceObject15, serializableAppearanceObject16, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.repositoryItemButtonEdit3.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.repositoryItemButtonEdit3.Name = "repositoryItemButtonEdit3";
            this.repositoryItemButtonEdit3.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.gdAccount);
            this.groupBox2.Location = new System.Drawing.Point(13, 187);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(929, 103);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Account";
            // 
            // gdAccount
            // 
            this.gdAccount.Dock = System.Windows.Forms.DockStyle.Fill;
            gridLevelNode4.RelationName = "Level1";
            this.gdAccount.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode4});
            this.gdAccount.Location = new System.Drawing.Point(2, 16);
            this.gdAccount.MainView = this.gridViewResult;
            this.gdAccount.Name = "gdAccount";
            this.gdAccount.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEdit1,
            this.btnEdit,
            this.btnDelete});
            this.gdAccount.Size = new System.Drawing.Size(925, 85);
            this.gdAccount.TabIndex = 26;
            this.gdAccount.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewResult});
            // 
            // gridViewResult
            // 
            this.gridViewResult.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.AccountNumber,
            this.CurrencyCode,
            this.AccountType,
            this.SourceBankBranch,
            this.AccountCustomerOID,
            this.CREATE_BY,
            this.CREATE_DATE,
            this.UPDATE_BY,
            this.UPDATE_DATE});
            this.gridViewResult.GridControl = this.gdAccount;
            this.gridViewResult.Name = "gridViewResult";
            this.gridViewResult.OptionsBehavior.AllowIncrementalSearch = true;
            this.gridViewResult.OptionsView.BestFitMode = DevExpress.XtraGrid.Views.Grid.GridBestFitMode.Fast;
            this.gridViewResult.OptionsView.ShowGroupPanel = false;
            // 
            // AccountNumber
            // 
            this.AccountNumber.AppearanceHeader.Options.UseTextOptions = true;
            this.AccountNumber.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.AccountNumber.Caption = "Account Number";
            this.AccountNumber.FieldName = "AccountNumber";
            this.AccountNumber.Name = "AccountNumber";
            this.AccountNumber.OptionsColumn.AllowEdit = false;
            this.AccountNumber.Visible = true;
            this.AccountNumber.VisibleIndex = 0;
            this.AccountNumber.Width = 181;
            // 
            // CurrencyCode
            // 
            this.CurrencyCode.AppearanceHeader.Options.UseTextOptions = true;
            this.CurrencyCode.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.CurrencyCode.Caption = "Currency";
            this.CurrencyCode.FieldName = "CurrencyCode";
            this.CurrencyCode.Name = "CurrencyCode";
            this.CurrencyCode.OptionsColumn.AllowEdit = false;
            this.CurrencyCode.Visible = true;
            this.CurrencyCode.VisibleIndex = 1;
            this.CurrencyCode.Width = 181;
            // 
            // AccountType
            // 
            this.AccountType.AppearanceHeader.Options.UseTextOptions = true;
            this.AccountType.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.AccountType.Caption = "Account Type";
            this.AccountType.FieldName = "AccountType";
            this.AccountType.Name = "AccountType";
            this.AccountType.OptionsColumn.AllowEdit = false;
            this.AccountType.Visible = true;
            this.AccountType.VisibleIndex = 2;
            this.AccountType.Width = 181;
            // 
            // SourceBankBranch
            // 
            this.SourceBankBranch.AppearanceHeader.Options.UseTextOptions = true;
            this.SourceBankBranch.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.SourceBankBranch.Caption = "Source Bank Branch";
            this.SourceBankBranch.FieldName = "SourceBankBranch";
            this.SourceBankBranch.MaxWidth = 100;
            this.SourceBankBranch.Name = "SourceBankBranch";
            this.SourceBankBranch.OptionsColumn.AllowEdit = false;
            this.SourceBankBranch.Visible = true;
            this.SourceBankBranch.VisibleIndex = 3;
            this.SourceBankBranch.Width = 87;
            // 
            // AccountCustomerOID
            // 
            this.AccountCustomerOID.Caption = "CustomerOID";
            this.AccountCustomerOID.FieldName = "CustomerOID";
            this.AccountCustomerOID.MinWidth = 10;
            this.AccountCustomerOID.Name = "AccountCustomerOID";
            // 
            // CREATE_BY
            // 
            this.CREATE_BY.Caption = "CREATE_BY";
            this.CREATE_BY.FieldName = "CREATE_BY";
            this.CREATE_BY.Name = "CREATE_BY";
            // 
            // CREATE_DATE
            // 
            this.CREATE_DATE.Caption = "CREATE_DATE";
            this.CREATE_DATE.FieldName = "CREATE_DATE";
            this.CREATE_DATE.Name = "CREATE_DATE";
            // 
            // UPDATE_BY
            // 
            this.UPDATE_BY.Caption = "UPDATE_BY";
            this.UPDATE_BY.FieldName = "UPDATE_BY";
            this.UPDATE_BY.Name = "UPDATE_BY";
            // 
            // UPDATE_DATE
            // 
            this.UPDATE_DATE.Caption = "UPDATE_DATE";
            this.UPDATE_DATE.FieldName = "UPDATE_DATE";
            this.UPDATE_DATE.Name = "UPDATE_DATE";
            // 
            // repositoryItemButtonEdit1
            // 
            this.repositoryItemButtonEdit1.AutoHeight = false;
            this.repositoryItemButtonEdit1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Flat;
            this.repositoryItemButtonEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "VIEW", -1, true, true, false, editorButtonImageOptions5, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject17, serializableAppearanceObject18, serializableAppearanceObject19, serializableAppearanceObject20, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.repositoryItemButtonEdit1.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.repositoryItemButtonEdit1.Name = "repositoryItemButtonEdit1";
            this.repositoryItemButtonEdit1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // btnEdit
            // 
            this.btnEdit.AutoHeight = false;
            this.btnEdit.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "Edit", -1, true, true, false, editorButtonImageOptions6, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject21, serializableAppearanceObject22, serializableAppearanceObject23, serializableAppearanceObject24, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.btnEdit.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // btnDelete
            // 
            this.btnDelete.AutoHeight = false;
            this.btnDelete.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "Delete", -1, true, true, false, editorButtonImageOptions7, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject25, serializableAppearanceObject26, serializableAppearanceObject27, serializableAppearanceObject28, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.btnDelete.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtPrimaryBusinessType);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtRegBusinessName);
            this.groupBox1.Controls.Add(this.txtCustomerNO);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtCustomerID);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtCustomerName);
            this.groupBox1.Controls.Add(this.txtRegisterDate);
            this.groupBox1.Controls.Add(this.txtRegBusinessNameTH);
            this.groupBox1.Controls.Add(this.txtJuristicIDNo);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(13, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(929, 141);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Detail";
            // 
            // txtPrimaryBusinessType
            // 
            this.txtPrimaryBusinessType.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrimaryBusinessType.Location = new System.Drawing.Point(591, 103);
            this.txtPrimaryBusinessType.Name = "txtPrimaryBusinessType";
            this.txtPrimaryBusinessType.Size = new System.Drawing.Size(321, 23);
            this.txtPrimaryBusinessType.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(445, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 16);
            this.label6.TabIndex = 17;
            this.label6.Text = "Primary Business Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(489, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 16);
            this.label8.TabIndex = 15;
            this.label8.Text = "Business Name";
            // 
            // txtRegBusinessName
            // 
            this.txtRegBusinessName.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegBusinessName.Location = new System.Drawing.Point(591, 49);
            this.txtRegBusinessName.Name = "txtRegBusinessName";
            this.txtRegBusinessName.Size = new System.Drawing.Size(321, 23);
            this.txtRegBusinessName.TabIndex = 16;
            // 
            // txtCustomerNO
            // 
            this.txtCustomerNO.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerNO.Location = new System.Drawing.Point(591, 23);
            this.txtCustomerNO.Name = "txtCustomerNO";
            this.txtCustomerNO.Size = new System.Drawing.Size(321, 23);
            this.txtCustomerNO.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(505, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 16);
            this.label7.TabIndex = 13;
            this.label7.Text = "Customer No";
            // 
            // txtCustomerID
            // 
            this.txtCustomerID.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerID.Location = new System.Drawing.Point(123, 23);
            this.txtCustomerID.Name = "txtCustomerID";
            this.txtCustomerID.Size = new System.Drawing.Size(321, 23);
            this.txtCustomerID.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Customer Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(33, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Register Date";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerName.Location = new System.Drawing.Point(123, 49);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(321, 23);
            this.txtCustomerName.TabIndex = 3;
            // 
            // txtRegisterDate
            // 
            this.txtRegisterDate.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegisterDate.Location = new System.Drawing.Point(122, 103);
            this.txtRegisterDate.Name = "txtRegisterDate";
            this.txtRegisterDate.Size = new System.Drawing.Size(202, 23);
            this.txtRegisterDate.TabIndex = 9;
            // 
            // txtRegBusinessNameTH
            // 
            this.txtRegBusinessNameTH.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRegBusinessNameTH.Location = new System.Drawing.Point(123, 77);
            this.txtRegBusinessNameTH.Name = "txtRegBusinessNameTH";
            this.txtRegBusinessNameTH.Size = new System.Drawing.Size(321, 23);
            this.txtRegBusinessNameTH.TabIndex = 6;
            // 
            // txtJuristicIDNo
            // 
            this.txtJuristicIDNo.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtJuristicIDNo.Location = new System.Drawing.Point(591, 76);
            this.txtJuristicIDNo.Name = "txtJuristicIDNo";
            this.txtJuristicIDNo.Size = new System.Drawing.Size(321, 23);
            this.txtJuristicIDNo.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Business Name TH";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(501, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Juristic ID No";
            // 
            // btnClose
            // 
            this.btnClose.EditValue = "CLOSE";
            this.btnClose.Location = new System.Drawing.Point(901, 7);
            this.btnClose.Name = "btnClose";
            this.btnClose.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btnClose.Properties.Appearance.Options.UseFont = true;
            this.btnClose.Properties.AutoHeight = false;
            this.btnClose.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.btnClose.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Close)});
            this.btnClose.Properties.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Office2003;
            this.btnClose.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.btnClose.Size = new System.Drawing.Size(42, 29);
            this.btnClose.TabIndex = 4;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // splashScreenManager1
            // 
            this.splashScreenManager1.ClosingDelay = 500;
            // 
            // frmCustomerMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1097, 704);
            this.Controls.Add(this.popupContainerControl1);
            this.Controls.Add(this.gdView);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "frmCustomerMaster";
            this.Text = "Customer Master";
            this.Load += new System.EventHandler(this.frmCustomerMaster_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.popupContainerControl1)).EndInit();
            this.popupContainerControl1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gdAddress)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit3)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gdAccount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewResult)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnClose.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraGrid.Columns.GridColumn RegBusinessNameTH;
        private DevExpress.XtraGrid.Columns.GridColumn JuristicIDNo;
        private DevExpress.XtraGrid.Columns.GridColumn colDID;
        private DevExpress.XtraGrid.Columns.GridColumn colHID;
        private DevExpress.XtraGrid.Columns.GridColumn RegisterDate;
        private DevExpress.XtraGrid.Columns.GridColumn PrimaryBusinessTypeCode;
        private DevExpress.XtraGrid.Columns.GridColumn ContactTelNumber;
        private DevExpress.XtraGrid.Columns.GridColumn CustomerName;
        private DevExpress.XtraGrid.Columns.GridColumn DefaultAddress;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.Bar bar2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraGrid.GridControl gdView;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn No;
        private DevExpress.XtraGrid.Columns.GridColumn btnViewCustomer;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit btnView;
        private DevExpress.XtraGrid.Columns.GridColumn CustomerNo;
        private DevExpress.XtraGrid.Columns.GridColumn CustomerID;
        private DevExpress.XtraGrid.Columns.GridColumn CustomerACNo;
        private DevExpress.XtraGrid.Columns.GridColumn RegBusinessName;
        private DevExpress.XtraGrid.Columns.GridColumn RegisterAddress;
        private DevExpress.XtraGrid.Columns.GridColumn ContactAddress;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraGrid.Columns.GridColumn CompanyAdd;
        private DevExpress.XtraGrid.Columns.GridColumn SourceFile_MappingDetailName;
        private DevExpress.XtraEditors.PopupContainerControl popupContainerControl1;
        private DevExpress.XtraSplashScreen.SplashScreenManager splashScreenManager1;
        private DevExpress.XtraGrid.Columns.GridColumn CustomerOID;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.TextBox txtCustomerID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.ButtonEdit btnClose;
        private System.Windows.Forms.TextBox txtJuristicIDNo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtRegBusinessNameTH;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtRegisterDate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtCustomerNO;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtRegBusinessName;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtPrimaryBusinessType;
        private System.Windows.Forms.Label label6;
        private DevExpress.XtraGrid.GridControl gdAddress;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraGrid.Columns.GridColumn RelateCustomerKYCID;
        private DevExpress.XtraGrid.Columns.GridColumn PrincipleAddress;
        private DevExpress.XtraGrid.Columns.GridColumn City;
        private DevExpress.XtraGrid.Columns.GridColumn State;
        private DevExpress.XtraGrid.Columns.GridColumn Zipcode;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn Country;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit3;
        private DevExpress.XtraGrid.Columns.GridColumn AddressOID;
        private DevExpress.XtraGrid.Columns.GridColumn Address_CREATE_BY;
        private DevExpress.XtraGrid.Columns.GridColumn Address_CREATE_DATE;
        private DevExpress.XtraGrid.Columns.GridColumn Address_UPDATE_BY;
        private DevExpress.XtraGrid.Columns.GridColumn Address_UPDATE_DATE;
        private DevExpress.XtraGrid.Columns.GridColumn Address_CustomerOID;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit4;
        private DevExpress.XtraGrid.GridControl gdAccount;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewResult;
        private DevExpress.XtraGrid.Columns.GridColumn AccountNumber;
        private DevExpress.XtraGrid.Columns.GridColumn CurrencyCode;
        private DevExpress.XtraGrid.Columns.GridColumn AccountType;
        private DevExpress.XtraGrid.Columns.GridColumn SourceBankBranch;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit btnEdit;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit btnDelete;
        private DevExpress.XtraGrid.Columns.GridColumn AccountCustomerOID;
        private DevExpress.XtraGrid.Columns.GridColumn CREATE_BY;
        private DevExpress.XtraGrid.Columns.GridColumn CREATE_DATE;
        private DevExpress.XtraGrid.Columns.GridColumn UPDATE_BY;
        private DevExpress.XtraGrid.Columns.GridColumn UPDATE_DATE;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn ContactNumber;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView3;
        private DevExpress.XtraGrid.Columns.GridColumn gdAccCustomerID;
        private DevExpress.XtraGrid.Columns.GridColumn gdAccAccountNumber;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView4;
    }
}