using System;
using System.Collections.Generic;
using System.Text;

namespace DTO.Util
{

    public enum PAction
    {
        Add = 1,
        Update = 2,
        Delete = 3,
        None = 0
    }


    public enum SMSType
    {
        SMS = 1,
        WAP = 2,
    }

    public class  State
    {
     

     
    }
}
