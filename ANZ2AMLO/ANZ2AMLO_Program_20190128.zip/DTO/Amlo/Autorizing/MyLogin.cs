using System;
using System.Collections.Generic;
using System.Text;

namespace DTO.Amlo.Autorizing
{
    public static class MyLogin
    {
        public static string USER_OID;
	    public static string USERGROUP_OID; 
	    public static string USER_LOGIN;
	    public static string FName;
	    public static string LName; 
        public static string USERGroupName;
	    public static string Position; 
	    public static string Addr1; 
	    public static string Telephone;
	    public static string Email; 
	    public static string PASSWORD;
	    public static string MAX_SESSION;
	    public static string SESSION_TIME_OUT;
	    public static string CREATE_BY;
	    public static string CREATE_DATE; 
	    public static string UPDATE_BY; 
	    public static string UPDATE_DATE;
	    public static string ROW_STATE;
        public static string Active;
        public static DateTime LoginTime;
    }
}
